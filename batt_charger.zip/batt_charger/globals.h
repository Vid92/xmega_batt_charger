#ifndef GLOBALS_H_
#define GLOBALS_H_

#pragma once
#include <Arduino.h>

#define Debug Serial4

#endif
